/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Capa3_AccesoDatos;

import static Capa3_AccesoDatos.ClaseConexion.getConnection;
import Capa_Entidades.Factura;
//import Config.Config;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Claudio
 */
public class ADFactura {
    
    private Connection _cnn;
    private String _mensaje;
    
    
     public ADFactura() throws Exception {
//        try {
//            String url = Config.getConnectionString();
//            _cnn = DriverManager.getConnection(url);
//            _mensaje = "";
//        } catch (Exception e) {
//            throw e;
//        }
    }
      public String getMensaje() {
        return _mensaje;
    }
      
     
     //ACTUALIZADO Y CAMBIADO A LA VERSIÓN WEB DEL MÉTODO
    public int InsertarFactura(Factura factura) throws Exception {
        Connection _conexion = null;
        PreparedStatement stmt = null;
        int idFactura = -1;

        try {
            _conexion = getConnection();
            String sentencia = "INSERT INTO FACTURAS (ID_CLIENTE, ID_USUARIO, FECHA, ESTADO, TOTAL_VENTA) VALUES (?, ?, ?, ?, ?)";
            stmt = _conexion.prepareStatement(sentencia, Statement.RETURN_GENERATED_KEYS);

            stmt.setInt(1, factura.getIdCliente());
            stmt.setInt(2, factura.getIdUsuario());
            stmt.setDate(3, new java.sql.Date(factura.getFecha().getTime()));
            stmt.setString(4, factura.getEstado());
            stmt.setDouble(5, factura.getTotalVenta());

            stmt.execute();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs != null && rs.next()) {
                idFactura = rs.getInt(1);
                _mensaje = "Factura ingresada satisfactoriamente";
            }
        } catch (Exception e) {
            _mensaje = "Error inesperado, intente más tarde";
            throw e;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return idFactura;
    }

  
  
     
     //LISTAR  MODIFICADO PARA LA VERSIÓN WEB
    public List<Factura> ListarRegistros(String condicion) throws Exception {
        ResultSet rs = null;
        Factura factura;
        List<Factura> lista = new ArrayList<>();
        Connection connection = null;
        try {
            // Obtener la conexión desde la clase ClaseConexion
            connection = ClaseConexion.getConnection();
            Statement stmt = connection.createStatement();
            String Sentencia;
            Sentencia= "SELECT ID_FACTURA, ID_CLIENTE, ID_USUARIO, FECHA, ESTADO, TOTAL_VENTA FROM FACTURAS";

            if (!condicion.isEmpty()) {
                Sentencia += " WHERE " + condicion;
            }

            rs = stmt.executeQuery(Sentencia);

            while (rs.next()) {
                factura = new Factura();
                factura.setIdFactura(rs.getInt("ID_FACTURA"));
                factura.setIdCliente(rs.getInt("ID_CLIENTE"));
                factura.setIdUsuario(rs.getInt("ID_USUARIO"));
                factura.setFecha(rs.getDate("FECHA"));
                factura.setEstado(rs.getString("ESTADO"));
                factura.setTotalVenta(rs.getDouble("TOTAL_VENTA"));
                lista.add(factura);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (connection != null) {
                ClaseConexion.close(connection);
            }
        }
        return lista;
    }

    
    
    // MODIFICADO PARA LA VERSIÓN WEB ObtenerRegistro
    
    public Factura ObtenerRegistro(String condicion) throws Exception {
        Factura factura = new Factura();
        ResultSet rs = null;
        Connection connection = null;
        try {
            // Obtener la conexión desde la clase ClaseConexion
            connection = ClaseConexion.getConnection();
            Statement stmt = connection.createStatement();
            String query = "SELECT ID_FACTURA, ID_CLIENTE, ID_USUARIO, FECHA, ESTADO, TOTAL_VENTA FROM FACTURAS";

            if (!condicion.isEmpty()) {
                query += " WHERE " + condicion;
            }

            rs = stmt.executeQuery(query);

            if (rs.next()) {
                factura.setIdFactura(rs.getInt("ID_FACTURA"));
                factura.setIdCliente(rs.getInt("ID_CLIENTE"));
                factura.setIdUsuario(rs.getInt("ID_USUARIO"));
                factura.setFecha(rs.getDate("FECHA"));
                factura.setEstado(rs.getString("ESTADO"));
                factura.setTotalVenta(rs.getDouble("TOTAL_VENTA"));

                factura.setExiste(true);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (connection != null) {
                ClaseConexion.close(connection);
            }
        }
        return factura;
    }


    //Modificar adapatado a WEB
    public int ModificarFactura(Factura factura) throws Exception {
        int resultado = 0;
        Connection connection = null;
        try {
            // Obtener la conexión desde la clase ClaseConexion
            connection = ClaseConexion.getConnection();
            String sentencia = "UPDATE FACTURAS SET ID_CLIENTE=?, ID_USUARIO=?, FECHA=?, ESTADO=?, TOTAL_VENTA=? WHERE ID_FACTURA=?";
            PreparedStatement ps = connection.prepareStatement(sentencia);
            ps.setInt(1, factura.getIdCliente());
            ps.setInt(2, factura.getIdUsuario());
            ps.setDate(3, new java.sql.Date(factura.getFecha().getTime()));
            ps.setString(4, factura.getEstado());
            ps.setDouble(5, factura.getTotalVenta());
            ps.setInt(6, factura.getIdFactura());

            resultado = ps.executeUpdate();
            if (resultado > 0) {
                _mensaje = "Registro modificado satisfactoriamente";
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (connection != null) {
                ClaseConexion.close(connection);
            }
        }
        return resultado;
    }


        //Adaptado VERSIÓN WEB
    public int EliminarFactura(Factura factura) throws Exception {
        int resultado = 0;
        Connection connection = null;
        try {
            // Obtener la conexión desde la clase ClaseConexion
            connection = ClaseConexion.getConnection();
            String sentencia = "DELETE FROM FACTURAS WHERE ID_FACTURA=?";
            PreparedStatement ps = connection.prepareStatement(sentencia);
            ps.setInt(1, factura.getIdFactura());
            resultado = ps.executeUpdate();
            if (resultado > 0) {
                _mensaje = "Registro eliminado satisfactoriamente";
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (connection != null) {
                ClaseConexion.close(connection);
            }
        }
        return resultado;
    }



    
    
//    public List<Integer> obtenerIdUsuarios() throws Exception {
//        List<Integer> listaUsuarios = new ArrayList<>();
//        ResultSet rs = null;
//
//        try {
//            String sentencia = "SELECT ID_USUARIO FROM USUARIOS";
//            PreparedStatement ps = _cnn.prepareStatement(sentencia);
//            rs = ps.executeQuery();
//
//            while (rs.next()) {
//                int idUsuario = rs.getInt("ID_USUARIO");
//                listaUsuarios.add(idUsuario);
//            }
//
//        } catch (Exception e) {
//            throw e;
//        }
//
//        return listaUsuarios;
//    }
//    public List<Integer> obtenerIdUsuarios() throws Exception {
//        List<Integer> listaUsuarios = new ArrayList<>();
//        ResultSet rs = null;
//
//        try {
//            String sentencia = "SELECT ID_USUARIO FROM USUARIOS";
//            PreparedStatement ps = _cnn.prepareStatement(sentencia);
//            rs = ps.executeQuery();
//
//            while (rs.next()) {
//                int idUsuario = rs.getInt("ID_USUARIO");
//                listaUsuarios.add(idUsuario);
//            }
//
//        } catch (Exception e) {
//            throw e;
//        }
//
//        return listaUsuarios;
//    }
public List<Integer> obtenerIdUsuarios() throws Exception {
        List<Integer> listaUsuarios = new ArrayList<>();
        ResultSet rs = null;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection(); // Obtener la conexión a la base de datos

            String sentencia = "SELECT ID_USUARIO FROM USUARIOS";
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            rs = ps.executeQuery();

            while (rs.next()) {
                int idUsuario = rs.getInt("ID_USUARIO");
                listaUsuarios.add(idUsuario);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return listaUsuarios;
    }


       public int ModificarEstado(Factura EntidadFactura) throws Exception {
        int resultado = 0;
        Connection _Conexion = null;
        // dentro del try no se puede declarar, porque entonces no podriamos cerrarla en el Finally
        // O, podria declararse y cerrarse dentro del Try
        try {
            _Conexion = ClaseConexion.getConnection();
            PreparedStatement PS = _Conexion.prepareStatement("update Factura set Estado = ? where NUM_FACTURA = ?");

            PS.setString(1, EntidadFactura.getEstado());
            PS.setInt(2, EntidadFactura.getIdFactura());

            resultado = PS.executeUpdate();

        } catch (Exception ex) {
            resultado = -1;
            throw ex;
        } finally {
            if (_Conexion != null) {
                ClaseConexion.close(_Conexion);
            }
            // .close y .getConnection son metodos estaticos de la clase ClaseConexion, si uno quisiera escribirlos sin 
            // ClaseConexion.  entonces solamente debe importar la clase
        }
        return resultado;
    } // fin ModificarEstado


    
    
      
      
      //Este método implementa el uso de un procedimiento almacenado
    
//    public int Eliminar(int idFactura) throws Exception {
//        int resultado = 0;
//        String sentencia = "{call EliminarFacturaConDetalles(?)}"; // Cambia el nombre del procedimiento almacenado si es diferente
//
//        try (CallableStatement callableStatement = _cnn.prepareCall(sentencia)) {
//            callableStatement.setInt(1, idFactura);  //callbleStatement es utilizada para invocar procedimientos almacenados en una base de datos
//            resultado = callableStatement.executeUpdate();
//
//            if (resultado > 0) {
//                _mensaje = "Factura eliminada satisfactoriamente";
//            }
//        } catch (Exception ex) {
//            throw ex;
//        } finally {
//            // Cierra recursos, si es necesario
//        }
//
//        return resultado;
//    }

    
    
    
    
}
