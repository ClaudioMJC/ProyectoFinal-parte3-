/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Capa3_AccesoDatos;

import static Capa3_AccesoDatos.ClaseConexion.getConnection;
import Capa_Entidades.Producto;
//import Config.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Claudio
 */
public class ADProducto {
    
     private Connection _cnn;
    private String _mensaje;

    //Constructor
    public ADProducto() throws Exception {
//        try {
//            String url = Config.getConnectionString();
//            _cnn = DriverManager.getConnection(url);
//            _mensaje = "";
//        } catch (Exception e) {
//            throw e;
//        }
    }

    //Getter
    public String getMensaje() {
        return _mensaje;
    }
    
    
    //Insertar
    public int Insertar(Producto producto) throws Exception {
        PreparedStatement stmt = null;
        int resultado = -1;
        Connection _conexion = null;

        try {
            _conexion = getConnection();
            String sql;

            if (producto.getId_producto() <= 0) {
                // Insertar un nuevo producto
                sql = "INSERT INTO PRODUCTOS (ID_PROVEEDOR, DESCRIPCION, PRECIOCOMPRA, PRECIOVENTA) VALUES (?, ?, ?, ?)";
                stmt = _conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            } else {
                // Actualizar un producto existente
                sql = "UPDATE PRODUCTOS SET ID_PROVEEDOR = ?, DESCRIPCION = ?, PRECIOCOMPRA = ?, PRECIOVENTA = ? WHERE ID_PRODUCTO = ?";
                stmt = _conexion.prepareStatement(sql);
                stmt.setInt(5, producto.getId_producto());
            }

            stmt.setInt(1, producto.getId_proveedor());
            stmt.setString(2, producto.getDescripcion());
            stmt.setDouble(3, producto.getPrecioCompra());
            stmt.setDouble(4, producto.getPrecioVenta());

            resultado = stmt.executeUpdate();

            if (resultado > 0 && producto.getId_producto() <= 0) {
                // Si es una inserción, obtén el ID generado
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    producto.setId_producto(generatedKeys.getInt(1));
                }
            }

        } catch (Exception ex) {
            _mensaje = "Error inesperado, intente más tarde";
            throw ex;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return resultado;
    }


    
    
    
    //////////////////////
    
    public List<Producto> ListarRegistros(String condicion) throws Exception {
        ResultSet rs = null;
        Producto producto;
        List<Producto> lista = new ArrayList<>();
        Connection _conexion = null;
        try {
            // Abrir la conexión:
            _conexion = ClaseConexion.getConnection();

            Statement st = _conexion.createStatement();
            String sentencia = "SELECT ID_PRODUCTO, ID_PROVEEDOR, DESCRIPCION, PRECIOCOMPRA, PRECIOVENTA FROM PRODUCTOS";

            if (!condicion.equals("")) {
                sentencia = String.format("%s WHERE %s", sentencia, condicion);
            }

            rs = st.executeQuery(sentencia);

            // Recorremos el ResultSet agregando cada Registro a la Lista
            while (rs.next()) {
                producto = new Producto(rs.getInt(1), rs.getInt(2), rs.getString(3), rs.getDouble(4), rs.getDouble(5));
                lista.add(producto);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return lista;
    }


    
    
    
    // Obtener un registro de Producto
public Producto ObtenerRegistro(String condicion) throws Exception {

        ResultSet rs = null;
        Producto producto = new Producto();
        String sentencia;
        Connection _conexion = null;
        try {
            _conexion = ClaseConexion.getConnection();
            Statement st = _conexion.createStatement();

            sentencia = "SELECT ID_PRODUCTO, ID_PROVEEDOR, DESCRIPCION, PRECIOCOMPRA, PRECIOVENTA FROM PRODUCTOS";
            if (!condicion.equals("")) {
                sentencia = String.format("%s WHERE %s", sentencia, condicion);
            }
            rs = st.executeQuery(sentencia);

            // Con If y no While, por si esta consulta hubiera retornado varios registros, 
            // lee solamente uno (el primero).
            // En teoría, eso nunca va a pasar si en la condición el método recibe el ID de un producto.
            if (rs.next()) {
                producto.setId_producto(rs.getInt(1));
                producto.setId_proveedor(rs.getInt(2));
                producto.setDescripcion(rs.getString(3));
                producto.setPrecioCompra(rs.getDouble(4));
                producto.setPrecioVenta(rs.getDouble(5));
                producto.setExiste(true);
            } else {
                producto.setExiste(false);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return producto;
    }





// Modificar un Producto
public int Modificar(Producto entidadProducto) throws Exception {
        int resultado = -1;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection();
            PreparedStatement ps = _conexion.prepareStatement("UPDATE PRODUCTOS SET DESCRIPCION=?, PRECIOCOMPRA=?, PRECIOVENTA=? WHERE ID_PRODUCTO = ?");

            ps.setString(1, entidadProducto.getDescripcion());
            ps.setDouble(2, entidadProducto.getPrecioCompra());
            ps.setDouble(3, entidadProducto.getPrecioVenta());
            ps.setInt(4, entidadProducto.getId_producto());

            resultado = ps.executeUpdate();
        } catch (Exception ex) {
            throw new Exception("Error al modificar el producto: " + ex.getMessage());
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return resultado;
    }


    public int Eliminar(Producto producto) throws Exception {
        int resultado = 0;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection();
            String sentencia = "DELETE FROM PRODUCTOS WHERE ID_PRODUCTO=?";
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            ps.setInt(1, producto.getId_producto());
            resultado = ps.executeUpdate();
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return resultado;
    }


////public int Eliminar(Producto producto) throws Exception {
////    int resultado = 0;
////    String sentencia = "DELETE FROM Productos WHERE ID_PRODUCTO=?";
////    try {
////        PreparedStatement ps = _cnn.prepareStatement(sentencia);
////        ps.setInt(1, producto.getId_producto());
////        resultado = ps.executeUpdate();
////        if (resultado > 0) {
////            _mensaje = "Registro eliminado satisfactoriamente";
////        }
////    } catch (Exception ex) {
////        throw ex;
////    } finally {
////        _cnn = null;
////    }
////    return resultado;
////}

    



    // Método para obtener la lista de proveedores
    public List<String> obtenerProveedores() throws Exception {
        List<String> listaProveedores = new ArrayList<>();
        ResultSet rs = null;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection();
            String sentencia = "SELECT ID_PROVEEDOR, DESCRIPCION FROM PROVEEDORES";
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            rs = ps.executeQuery();

            while (rs.next()) {
                int idProveedor = rs.getInt("ID_PROVEEDOR");
                String descripcion = rs.getString("DESCRIPCION");
                String infoProveedor = "id_proveedor = " + idProveedor + " - " + descripcion;
                listaProveedores.add(infoProveedor);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return listaProveedores;
    }

    public List<Integer> obtenerIdProveedores() throws Exception {
        List<Integer> listaProveedores = new ArrayList<>();
        ResultSet rs = null;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection();
            String sentencia = "SELECT ID_PROVEEDOR FROM PROVEEDORES";
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            rs = ps.executeQuery();

            while (rs.next()) {
                int idProveedor = rs.getInt("ID_PROVEEDOR");
                listaProveedores.add(idProveedor);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return listaProveedores;
    }

   
   
   
    
    
    
}
