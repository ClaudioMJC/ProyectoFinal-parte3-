/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Capa3_AccesoDatos;

import static Capa3_AccesoDatos.ClaseConexion.getConnection;
import Capa_Entidades.Proveedor;
//import Config.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Claudio
 */
public class ADProveedor {
    
    private Connection _cnn;
    private String _mensaje;

    //Constructor
    public ADProveedor() throws Exception {
//        try {
//            String url = Config.getConnectionString();
//            _cnn = DriverManager.getConnection(url);
//            _mensaje = "";
//        } catch (Exception e) {
//            throw e;
//        }
    }

    //Getter
    public String getMensaje() {
        return _mensaje;
    }

    ////////////////////////////////////////////////////////////////////// 
// Método para Insertar un proveedor
    public int Insertar(Proveedor proveedor) throws Exception {
        PreparedStatement stmt = null;
        int resultado = -1;
        Connection _conexion = null;

        try {
            _conexion = getConnection();
            String sql;

            if (proveedor.getIdProveedor() <= 0) {
                // Insertar un nuevo proveedor
                sql = "INSERT INTO PROVEEDORES (NOMBRE, APELLIDO, TELEFONO, DESCRIPCION) VALUES (?, ?, ?, ?)";
                stmt = _conexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            } else {
                // Actualizar un proveedor existente
                sql = "UPDATE PROVEEDORES SET NOMBRE = ?, APELLIDO = ?, TELEFONO = ?, DESCRIPCION = ? WHERE ID_PROVEEDOR = ?";
                stmt = _conexion.prepareStatement(sql);
                stmt.setInt(5, proveedor.getIdProveedor());
            }

            stmt.setString(1, proveedor.getNombre());
            stmt.setString(2, proveedor.getApellido());
            stmt.setString(3, proveedor.getTelefono());
            stmt.setString(4, proveedor.getDescripcion());

            resultado = stmt.executeUpdate();

            if (resultado > 0 && proveedor.getIdProveedor() <= 0) {
                // Si es una inserción, obtén el ID generado
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    proveedor.setIdProveedor(generatedKeys.getInt(1));
                }
            }

        } catch (Exception ex) {
            _mensaje = "Error inesperado, intente más tarde";
            throw ex;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return resultado;
    }


    
// Listar Registros
    public List<Proveedor> ListarRegistros(String Condicion) throws Exception {
        ResultSet rs = null;
        Proveedor proveedor;
        List<Proveedor> lista = new ArrayList<>();
        Connection _conexion = null;
        try {
            // Abrir la conexión:
            _conexion = ClaseConexion.getConnection();

            Statement st = _conexion.createStatement();
            String Sentencia;

            Sentencia = "Select id_proveedor, nombre, apellido, telefono, descripcion from proveedores";

            if (!Condicion.equals("")) {
                Sentencia = String.format("%s WHERE %s", Sentencia, Condicion);
            }

            rs = st.executeQuery(Sentencia);

            // Recorremos el ResultSet agregando cada Registro a la Lista
            while (rs.next()) {
                proveedor = new Proveedor(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                lista.add(proveedor);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return lista;
    }


    
// Obtener Registro
    public Proveedor ObtenerRegistro(String Condicion) throws Exception {
        // La idea es que la Condición que ingresa permita conseguir un registro único y no varios!
        // Por tanto, al llamar a este método, debemos garantizar que SIEMPRE le enviemos en la condición
        // el ID de un proveedor.

        ResultSet rs = null;
        Proveedor proveedor = new Proveedor();
        String sentencia;
        Connection _conexion = null;
        try {
            _conexion = ClaseConexion.getConnection();
            Statement st = _conexion.createStatement();

            sentencia = "SELECT ID_PROVEEDOR, NOMBRE, APELLIDO, TELEFONO, DESCRIPCION FROM PROVEEDORES";
            if (!Condicion.equals("")) {
                sentencia = String.format("%s WHERE %s", sentencia, Condicion);
            }
            rs = st.executeQuery(sentencia);

            // Con If y no While, por si esta consulta hubiera retornado varios registros, 
            // lee solamente uno (el primero).
            // En teoría, eso nunca va a pasar si en la condición el método recibe el ID de un proveedor
            if (rs.next()) {
                proveedor.setIdProveedor(rs.getInt(1));
                proveedor.setNombre(rs.getString(2));
                proveedor.setApellido(rs.getString(3));
                proveedor.setTelefono(rs.getString(4));
                proveedor.setDescripcion(rs.getString(5));
                proveedor.setExiste(true);
            } else {
                proveedor.setExiste(false);
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }
        return proveedor;
    }


    
    
// Modificar Proveedor
    public int Modificar(Proveedor proveedor) throws Exception {
        int resultado = -1;
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection();
            PreparedStatement ps = _conexion.prepareStatement("UPDATE PROVEEDORES SET NOMBRE=?, APELLIDO=?, TELEFONO=?, DESCRIPCION=? WHERE ID_PROVEEDOR = ?");

            ps.setString(1, proveedor.getNombre());
            ps.setString(2, proveedor.getApellido());
            ps.setString(3, proveedor.getTelefono());
            ps.setString(4, proveedor.getDescripcion());
            ps.setInt(5, proveedor.getIdProveedor());

            resultado = ps.executeUpdate();
        } catch (Exception ex) {
            throw new Exception("Error al modificar el proveedor: " + ex.getMessage());
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return resultado;
    }


// Eliminar Proveedor
    public int Eliminar(Proveedor proveedor) throws Exception {
        int resultado = 0;
        Connection _conexion = null;
        String sentencia = "DELETE FROM PROVEEDORES WHERE ID_PROVEEDOR = ?";

        try {
            _conexion = ClaseConexion.getConnection();
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            ps.setInt(1, proveedor.getIdProveedor());
            resultado = ps.executeUpdate();

            if (resultado > 0) {
                _mensaje = "Proveedor eliminado satisfactoriamente";
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return resultado;
    }

    
    
    
//    public int Eliminar(Proveedor proveedor) throws Exception {
//        int resultado = 0;
//        String sentencia = "DELETE FROM PROVEEDORES WHERE ID_PROVEEDOR=?";
//        try {
//            PreparedStatement ps = _cnn.prepareStatement(sentencia);
//            ps.setInt(1, proveedor.getIdProveedor());
//            resultado = ps.executeUpdate();
//            if (resultado > 0) {
//                _mensaje = "Proveedor eliminado satisfactoriamente";
//            }
//        } catch (Exception ex) {
//            throw ex;
//        } finally {
//            _cnn = null;
//        }
//        return resultado;
//    }

    
    
    
}
