/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Capa3_AccesoDatos;

import static Capa3_AccesoDatos.ClaseConexion.getConnection;
import Capa_Entidades.Detalle_Factura;
import java.sql.CallableStatement;
//import Config.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Claudio
 */
public class ADDetalle_Factura {
    
     private Connection _cnn;
    private String _mensaje;

    public ADDetalle_Factura() throws Exception {
//        try {
//            String url = Config.getConnectionString();
//            _cnn = DriverManager.getConnection(url);
//            _mensaje = "";
//        } catch (Exception e) {
//            throw e;
//        }
    }

    public String getMensaje() {
        return _mensaje;
    }
      
    //versión web
    ///////////////////////////////  
    public int InsertarDetalleFactura(Detalle_Factura detalleFactura) throws Exception {
        Connection _conexion = null;
        PreparedStatement stmt = null;
        int idDetalleFactura = -1;

        try {
            _conexion = ClaseConexion.getConnection(); // Obtener la conexión a la base de datos
            String sentencia = "INSERT INTO DETALLE_FACTURAS (ID_FACTURA, ID_PRODUCTO, CANTIDAD) VALUES (?, ?, ?)";
            stmt = _conexion.prepareStatement(sentencia, Statement.RETURN_GENERATED_KEYS);

            stmt.setInt(1, detalleFactura.getIdFactura());
            stmt.setInt(2, detalleFactura.getIdProducto());
            stmt.setInt(3, detalleFactura.getCantidad());

            stmt.execute();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs != null && rs.next()) {
                idDetalleFactura = rs.getInt(1);
                _mensaje = "Detalle de factura ingresado satisfactoriamente";
            }
        } catch (Exception e) {
            _mensaje = "Error inesperado, intente más tarde";
            throw e;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
            if (_conexion != null) {
                ClaseConexion.close(_conexion);
            }
        }

        return idDetalleFactura;
    }


      
  //////////VERSIÓN WEB  27-10-2023
    public List<Detalle_Factura> ListarRegistros(String condicion) throws Exception {
        ResultSet rs = null;
        List<Detalle_Factura> lista = new ArrayList<>();
        Connection _conexion = null;

        try {
            _conexion = ClaseConexion.getConnection(); // Obtener la conexión a la base de datos
            String sentencia = "SELECT ID_FACTURA, ID_PRODUCTO, CANTIDAD FROM DETALLE_FACTURAS";

            if (!condicion.equals("")) {
                sentencia = String.format("%s WHERE %s", sentencia, condicion);
            }

            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new Detalle_Factura(
                        rs.getInt("ID_FACTURA"),
                        rs.getInt("ID_PRODUCTO"),
                        rs.getInt("CANTIDAD")
                ));
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (_conexion!=null) {
               ClaseConexion.close(_conexion); // Cerrar la conexión en el bloque "finally" 
            
            }
            
            
        }

        return lista;
    }

///////////////////////////////////
    
    
    //WEB VERSIÓN
    public Detalle_Factura ObtenerRegistro(String condicion) throws Exception {
        Detalle_Factura detalleFactura = new Detalle_Factura();
        ResultSet rs = null;
        Connection _conexion = null; // Agrega la conexión

        try {
            _conexion = ClaseConexion.getConnection(); // Obtener la conexión a la base de datos
            String sentencia = "SELECT ID_FACTURA, ID_PRODUCTO, CANTIDAD FROM DETALLE_FACTURAS";

            if (!condicion.equals("")) {
                sentencia = String.format("%s WHERE %s", sentencia, condicion);
            }

            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            rs = ps.executeQuery();

            if (rs.next()) {
                detalleFactura.setIdFactura(rs.getInt("ID_FACTURA"));
                detalleFactura.setIdProducto(rs.getInt("ID_PRODUCTO"));
                detalleFactura.setCantidad(rs.getInt("CANTIDAD"));

                detalleFactura.setExiste(true);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion); // Cerrar la conexión en el bloque "finally"
            }
        }

        return detalleFactura;
    }

 ///////////////////////
    
    
    public int ModificarDetalleFactura(Detalle_Factura detalleFactura) throws Exception {
        int resultado = 0;
        Connection _conexion = null;

        String sentencia = "UPDATE DETALLE_FACTURAS SET ID_PRODUCTO=?, CANTIDAD=? WHERE ID_FACTURA=?";
        try {
            _conexion = ClaseConexion.getConnection(); // Obtener la conexión a la base de datos
            PreparedStatement ps = _conexion.prepareStatement(sentencia);
            ps.setInt(1, detalleFactura.getIdProducto());
            ps.setInt(2, detalleFactura.getCantidad());
            ps.setInt(3, detalleFactura.getIdFactura());
            resultado = ps.executeUpdate();

            if (resultado > 0) {
                _mensaje = "Registro de Detalle de Factura modificado satisfactoriamente";
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (_conexion != null) {
                ClaseConexion.close(_conexion); // Cerrar la conexión en el bloque "finally"
            }
        }

        return resultado;
    }
    
    
    
    public int EliminarDetalleFactura(Detalle_Factura detalleFactura) throws Exception {
        int resultado = 0;
        Connection _conexion = null;
        CallableStatement cs = null;

        try {
            _conexion = ClaseConexion.getConnection(); // Obtiene la conexión de la misma manera que se venía haciendo

            cs = _conexion.prepareCall("{call EliminarFacturaConDetalles(?)}");
            cs.setInt(1, detalleFactura.getIdFactura());
            cs.execute();
            resultado = cs.getUpdateCount();

            if (resultado > 0) {
                _mensaje = "Registro de Detalle de Factura eliminado satisfactoriamente";
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (cs != null) {
                cs.close();
            }
            if (_conexion != null) {
                _conexion.close(); // Cierra la conexión de la misma manera que se venía haciendo
            }
        }
        return resultado;
    }



//    public int EliminarDetalleFactura(Detalle_Factura detalleFactura) throws Exception {
//        int resultado = 0;
//        String sentencia = "DELETE FROM DETALLE_FACTURA WHERE ID_FACTURA=?";
//        Connection _conexion = null;
//        try {
//            _conexion = ClaseConexion.getConnection();
//            PreparedStatement ps = _conexion.prepareStatement(sentencia);
//            ps.setInt(1, detalleFactura.getIdFactura());
//            resultado = ps.executeUpdate();
//            if (resultado > 0) {
//                _mensaje = "Registro de Detalle de Factura eliminado satisfactoriamente";
//            }
//        } catch (Exception ex) {
//            throw ex;
//        } finally {
//            if (_conexion != null) {
//                ClaseConexion.close(_conexion);
//            }
//        }
//        return resultado;
//    }

    
    
    
   

      
    
    
}
