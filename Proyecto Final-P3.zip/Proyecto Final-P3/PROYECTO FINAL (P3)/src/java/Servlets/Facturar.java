/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import Capa2_LogicaNegocio.LNDetalle_Factura;
import Capa2_LogicaNegocio.LNFactura;
import Capa_Entidades.Detalle_Factura;
import Capa_Entidades.Factura;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Claudio
 */
public class Facturar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        PrintWriter out = response.getWriter();
//        try {
//        LNFactura LogicaFactura = new LNFactura();
//        LNDetalle_Factura logicaDetalle = new LNDetalle_Factura();
//        Factura EntidadFactura = new Factura();
//        Detalle_Factura EntidadDetalle = new Detalle_Factura();
//        int resultado=0;
//        String mensaje = "";
//
//        // Crear entidad de factura
//        if (request.getParameter("txtnumFactura") != null && !request.getParameter("txtnumFactura").equals("")) {
//            EntidadFactura.setIdFactura(Integer.parseInt(request.getParameter("txtnumFactura")));
//
//            if (request.getParameter("cboUsuario") != null) {
//                // Asignar el usuario seleccionado
//                EntidadFactura.setIdUsuario(Integer.parseInt(request.getParameter("cboUsuario")));
//            }
//
//            if (request.getParameter("cboEstado") != null) {
//                // Asignar el estado seleccionado
//                EntidadFactura.setEstado(request.getParameter("cboEstado"));
//            }
//
//            if (request.getParameter("txtFechaFactura") != null && !request.getParameter("txtFechaFactura").equals("")) {
//                // Convertir la fecha de texto a Date
//                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
//                String fechaString = request.getParameter("txtFechaFactura");
//                //Date fecha = formato.parse(fechaString);
//                java.util.Date fecha = formato.parse(fechaString);
//                java.sql.Date fechasql = new java.sql.Date(fecha.getTime());
//                EntidadFactura.setFecha(fechasql);
//            }
//
//            if (request.getParameter("txtIdCliente") != null && !request.getParameter("txtIdCliente").equals("")) {
//                // Asignar el ID del cliente
//                EntidadFactura.setIdCliente(Integer.parseInt(request.getParameter("txtIdCliente")));
//            }
//            
//            if (request.getParameter("txtTotal") != null && !request.getParameter("txtTotal").equals("")) {
//                // Asignar el ID del cliente
//                EntidadFactura.setTotalVenta(Integer.parseInt(request.getParameter("txtTotal")));
//            }
//
//            if (request.getParameter("txtdescripcion") != null && !request.getParameter("txtdescripcion").equals("") &&
//                request.getParameter("txtcantidad") != null && !request.getParameter("txtcantidad").equals("") &&
//                request.getParameter("txtprecio") != null && !request.getParameter("txtprecio").equals("")) {
//                // Crear entidad de detalle
//                EntidadDetalle.setIdFactura(-1);
//                EntidadDetalle.setIdProducto(Integer.parseInt(request.getParameter("txtIdProducto")));
//                EntidadDetalle.setCantidad(Integer.parseInt(request.getParameter("txtcantidad")));
//                
//                resultado = LogicaFactura.InsertarFactura(EntidadFactura);
//                    EntidadDetalle.setIdFactura(resultado);
//                    logicaDetalle.InsertarDetalleFactura(EntidadDetalle);
//                    LogicaFactura.InsertarFactura(EntidadFactura);
//
//                mensaje = LogicaFactura.getMensaje();
//            } else {
//                mensaje = "Seleccione un producto";
//            }
//
//            response.sendRedirect("FrmListarFacturas.jsp?msgFac=" + mensaje + "&txtnumFactura=" + resultado);
//        } else {
//            response.sendRedirect("FrmListarFacturas.jsp?txtnumFactura=" + request.getParameter("txtnumFactura"));
//        }
//    } catch (Exception e) {
//        out.print(e.getMessage());
//    }
       
       protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            LNFactura LogicaFactura = new LNFactura();
            LNDetalle_Factura logicaDetalle = new LNDetalle_Factura();
            Factura EntidadFactura = new Factura();
            Detalle_Factura EntidadDetalle = new Detalle_Factura();
            int resultado = 0;
            String mensaje = "";

            // Crear entidad de factura
            if (request.getParameter("txtnumFactura") != null && !request.getParameter("txtnumFactura").isEmpty()) {
                EntidadFactura.setIdFactura(Integer.parseInt(request.getParameter("txtnumFactura")));

                if (request.getParameter("cboUsuario") != null) {
                    // Asignar el usuario seleccionado
                    EntidadFactura.setIdUsuario(Integer.parseInt(request.getParameter("cboUsuario")));
                }

                if (request.getParameter("cboEstado") != null) {
                    // Asignar el estado seleccionado
                    EntidadFactura.setEstado(request.getParameter("cboEstado"));
                }

                if (request.getParameter("txtFechaFactura") != null && !request.getParameter("txtFechaFactura").isEmpty()) {
                    // Convertir la fecha de texto a Date
                    SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                    String fechaString = request.getParameter("txtFechaFactura");
                    java.util.Date fecha = formato.parse(fechaString);
                    java.sql.Date fechasql = new java.sql.Date(fecha.getTime());
                    EntidadFactura.setFecha(fechasql);
                }

                if (request.getParameter("txtIdCliente") != null && !request.getParameter("txtIdCliente").isEmpty()) {
                    // Asignar el ID del cliente
                    EntidadFactura.setIdCliente(Integer.parseInt(request.getParameter("txtIdCliente")));
                }

                if (request.getParameter("txtTotal") != null && !request.getParameter("txtTotal").isEmpty()) {
                    // Asignar el total de venta
                    EntidadFactura.setTotalVenta(Double.parseDouble(request.getParameter("txtTotal")));
                }

                if (request.getParameter("txtdescripcion") != null && !request.getParameter("txtdescripcion").isEmpty()
                        && request.getParameter("txtcantidad") != null && !request.getParameter("txtcantidad").isEmpty()
                        && request.getParameter("txtprecio") != null && !request.getParameter("txtprecio").isEmpty()) {
                    // Crear entidad de detalle
                    EntidadDetalle.setIdFactura(-1);
                    EntidadDetalle.setIdProducto(Integer.parseInt(request.getParameter("txtIdProducto")));
                     EntidadDetalle.setCantidad(Integer.parseInt(request.getParameter("txtcantidad")));
                    //EntidadDetalle.setCantidad(Integer.parseInt(request.getParameter("txtcantidad"));
                    //EntidadDetalle.setPrecio(Double.parseDouble(request.getParameter("txtprecio")));

                    resultado = LogicaFactura.InsertarFactura(EntidadFactura);
                    EntidadDetalle.setIdFactura(resultado);
                    logicaDetalle.InsertarDetalleFactura(EntidadDetalle);

                    mensaje = LogicaFactura.getMensaje();
                } else {
                    mensaje = "Seleccione un producto";
                }

                response.sendRedirect("FrmListarFacturas.jsp?msgFac=" + mensaje + "&txtnumFactura=" + resultado);
            } else {
                response.sendRedirect("FrmListarFacturas.jsp?txtnumFactura=" + request.getParameter("txtnumFactura"));
            }
        } catch (Exception e) {
            // Manejo de excepciones mejorado: Registrar la excepción y mostrar un mensaje de error genérico
            e.printStackTrace();
            out.print("Ha ocurrido un error en el servidor.");
        }
    }

    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>

}

