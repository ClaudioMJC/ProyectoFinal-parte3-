/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Servlets;

import Capa2_LogicaNegocio.LNCliente;
import Capa_Entidades.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Claudio
 */
//@WebServlet("/CrearModificarCliente") 
public class CrearModificarCliente extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//
//        /*
//            Este Servlete va a hacer un trabajo muy sencillo, va a crear una entidad Cliente
//            para enviárselo al metodo correspondiente (insertar o modificar)
//        */
//        
//        response.setContentType("text/html;charset=UTF-8");
//
//        PrintWriter out = response.getWriter();
//        // No la incluimos dentro del Try, porque necesitamos usarla en el catch
//
//        try {
//            LNCliente Logica = new LNCliente();
//            Cliente cliente = new Cliente();
//            int resultado;
//
//            cliente.setIdCliente(Integer.parseInt(request.getParameter("txtCodigo")));
//            // txtCodigo sabemos que tiene un int, por ello lo parseamos a Intenger
//
//            cliente.setNombre(new String(request.getParameter("txtNombre").getBytes("ISO-8859-1"), "UTF-8"));
//             cliente.setApellido(new String(request.getParameter("txtApellido").getBytes("ISO-8859-1"), "UTF-8"));
//            // Los campos de texto les aplicamos una CODIFICACIÓN DE CARACTERES con un new String y con el 
//            // método getBytes. Esto por si viene con caracteres que no sean reconocidos por la BD por ejemplo. 
//            // De no hacer esta conversión, por ejemplo en lugar de las tildes o las ñ pueden aparecer símbolos "extraños" para el usuario
// 
//
//            cliente.setDireccion(new String(request.getParameter("txtDireccion").getBytes("ISO-8859-1"), "UTF-8"));
//            
//            
//            cliente.setTelefono(request.getParameter("txtTelefono"));
//           
//            
//            if (cliente.getIdCliente() > 0) {
//                resultado = Logica.Modificar(cliente);
//            } else {
//                resultado = Logica.Insertar(cliente);
//            }
//            response.sendRedirect("FrmListarClientes.jsp");
//
//        } catch (Exception ex) {
//            out.print(ex.getMessage());
//        }
//    }
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            LNCliente Logica = new LNCliente();
            Cliente cliente = new Cliente();
            int resultado;

            // Obtener datos del formulario
            cliente.setIdCliente(Integer.parseInt(request.getParameter("txtCodigo")));
            cliente.setNombre(new String(request.getParameter("txtNombre").getBytes("ISO-8859-1"), "UTF-8"));
            cliente.setApellido(new String(request.getParameter("txtApellido").getBytes("ISO-8859-1"), "UTF-8"));
            cliente.setDireccion(new String(request.getParameter("txtDireccion").getBytes("ISO-8859-1"), "UTF-8"));
            cliente.setTelefono(request.getParameter("txtTelefono"));

            // Determinar si es una operación de inserción o modificación
            if (cliente.getIdCliente() > 0) {
                resultado = Logica.Modificar(cliente); // Llama a un método que ejecuta SQL directamente
            } else {
                resultado = Logica.Insertar(cliente); // Llama a un método que ejecuta SQL directamente
            }

            // Redirigir a la página de listado de clientes
            response.sendRedirect("FrmListarClientes.jsp");

        } catch (Exception ex) {
            out.print(ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
